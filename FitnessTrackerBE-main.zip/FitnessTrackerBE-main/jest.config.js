module.exports = {
  verbose: true,
};
